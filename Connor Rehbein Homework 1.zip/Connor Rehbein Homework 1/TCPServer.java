import java.io.*;
import java.net.*;

/**
 * @author Connor Rehbein
 *
 */
public class TCPServer {

	private static int serverPort = 1236;
	
	/* Times that "a" is pressed */
	private static int countA = 0;
	
	/* Times that "b" is pressed */
	private static int countB = 0;
	
	/* Times that "c" is pressed */
	private static int countC = 0;
	
	/**
	 * The server code for the TCP connection.
	 *
	 * @param args Commandline arguments
	 */
	public static void main(String[] args) {
		
		try {
			ServerSocket welcomeSocket = new ServerSocket(serverPort);
			
			while (true) {
				
				/* Input Socket */
				Socket connectionSocket = welcomeSocket.accept();
				
				/* Reading input */
				BufferedReader scin = 
						new BufferedReader(new InputStreamReader(
								connectionSocket.getInputStream()));
				String letter = scin.readLine();
				
				/* Incrementing count and printing value */
				switch (letter) {
				case "a":
					countA++;
					System.out.println("Times \"a\" has been pressed: " +
					countA);
					break;
					
				case "b":
					countB++;
					System.out.println("Times \"b\" has been pressed: " +
					countB);
					break;
					
				case "c":
					countC++;
					System.out.println("Times \"c\" has been pressed: " +
					countC);
					break;
				}
				scin.close();
				connectionSocket.close();
			}
		} catch (IOException e) {
			System.out.println("Error receiving data: " + e.getMessage());
		}
		
	}

}
