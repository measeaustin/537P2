import java.io.IOException;
import java.net.*;

/**
 * @author Connor Rehbein
 *
 */
public class UDPServer {

	private static int serverPort = 1235;
	
	/* Times that "a" is pressed */
	private static int countA = 0;
	
	/* Times that "b" is pressed */
	private static int countB = 0;
	
	/* Times that "c" is pressed */
	private static int countC = 0;
	
	/**
	 * The server code for the UDP connection.
	 *
	 * @param args Commandline arguments
	 */
	public static void main(String[] args) {
		
		try {
			
			/* Input Socket */
			DatagramSocket serverSocket = new DatagramSocket(serverPort);
			byte[] receiveData = new byte[1024];
			
			while (true) {
				
				/* Reading input */
				DatagramPacket receivePacket = 
						new DatagramPacket(receiveData, receiveData.length);
				serverSocket.receive(receivePacket);
				String letter = 
						new String(receivePacket.getData(), 0,
								receivePacket.getLength());
				
				/* Incrementing count and printing value */
				switch (letter) {
				case "a":
					countA++;
					System.out.println("Times \"a\" has been pressed: " +
					countA);
					break;
					
				case "b":
					countB++;
					System.out.println("Times \"b\" has been pressed: " +
					countB);
					break;
					
				case "c":
					countC++;
					System.out.println("Times \"c\" has been pressed: " +
					countC);
					break;
				}
			}
		} catch (SocketException e) {
			System.out.println("Error creating socket: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("Error receiving data: " + e.getMessage());
		}
		
	}

}
