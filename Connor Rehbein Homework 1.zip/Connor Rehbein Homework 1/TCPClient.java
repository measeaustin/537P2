import java.io.*;
import java.net.*;
import java.util.Scanner;

/**
 * @author Connor Rehbein
 *
 */
public class TCPClient {

	/**
	 * The client code for the TCP connection.
	 *
	 * @param args Commandline arguments
	 */
	public static void main(String[] args) {
		
		/* Scanner for user input */
		Scanner scin = new Scanner(System.in);
		
		System.out.print("Server IP: ");
		try {
			InetAddress serverIP = InetAddress.getByName(scin.nextLine());
			
			/* Server port number */
			int serverPort = 1236;
			
			
			System.out.println("Connected");
			while (true) {
				
				String inChar = scin.nextLine();
				if (inChar.equals("a") || inChar.equals("b") ||
						inChar.equals("c")) {
					
					/* Socket for sending characters */
					Socket clientSocket = new Socket(serverIP, serverPort);
					
					/* Sending to server */
					DataOutputStream outToServer = new DataOutputStream(
							clientSocket.getOutputStream());
					outToServer.writeBytes(inChar);
					clientSocket.close();
				}
				
			}
		} catch (UnknownHostException e) {
			System.out.println("Not a valid IP address");
		} catch (SocketException e) {
			System.out.println("Error creating socket: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("Error receiving data: " + e.getMessage());
		}
	}

}
