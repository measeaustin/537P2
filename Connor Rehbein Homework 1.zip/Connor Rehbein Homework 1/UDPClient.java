import java.io.IOException;
import java.net.*;
import java.util.Scanner;

/**
 * @author Connor Rehbein
 *
 */
public class UDPClient {

	/**
	 * The client code for the UDP connection.
	 *
	 * @param args Commandline arguments
	 */
	public static void main(String[] args) {
		
		/* Scanner for user input */
		Scanner scin = new Scanner(System.in);
		
		System.out.print("Server IP: ");
		try {
			InetAddress serverIP = InetAddress.getByName(scin.nextLine());
			
			/* Server port number */
			int serverPort = 1235;
			
			/* Socket for sending characters */
			DatagramSocket clientSocket = new DatagramSocket();
			while (true) {
				String inChar = scin.next();
				if (inChar.equals("a") || inChar.equals("b") ||
						inChar.equals("c")) {
					
					/* Sending to server */
					byte[] sendData = inChar.getBytes();
					DatagramPacket sendPacket =
							new DatagramPacket(sendData, sendData.length,
								serverIP, serverPort);
					clientSocket.send(sendPacket);
				}
			}
		} catch (UnknownHostException e) {
			System.out.println("Not a valid IP address");
		} catch (SocketException e) {
			System.out.println("Error creating socket: " + e.getMessage());
		} catch (IOException e) {
			System.out.println("Error receiving data: " + e.getMessage());
		}
	}

}
